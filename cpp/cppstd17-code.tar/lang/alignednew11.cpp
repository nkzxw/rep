
#include "alignednew11.hpp"

int main()
{
  auto p = new MyType32;
  //...
  delete p;
}

