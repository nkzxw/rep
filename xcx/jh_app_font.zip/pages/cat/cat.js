var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, a = "function" == typeof Symbol && "symbol" == t(Symbol.iterator) ? function(a) {
    return void 0 === a ? "undefined" : t(a);
} : function(a) {
    return a && "function" == typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : void 0 === a ? "undefined" : t(a);
}, e = !1, o = !1;

Page({
    data: {
        cat_list: [],
        sub_cat_list_scroll_top: 0,
        scrollLeft: 0,
        page: 1,
        cat_style: 0,
        height: 0,
        catheight: 120
    },
    onLoad: function(t) {
        var a = this;
        getApp().page.onLoad(a, t);
        var e = getApp().core.getStorageSync(getApp().const.STORE), o = t.cat_id;
        void 0 !== o && o && (a.data.cat_style = e.cat_style = -1, getApp().core.showLoading({
            title: "正在加载",
            mask: !0
        }), a.childrenCat(o)), a.setData({
            store: e
        });
    },
    onShow: function() {
        getApp().page.onShow(this), getApp().core.hideLoading(), -1 !== this.data.cat_style && this.loadData();
    },
    loadData: function(t) {
        var a = this, e = getApp().core.getStorageSync(getApp().const.STORE);
        if ("" == a.data.cat_list || 5 != e.cat_style && 4 != e.cat_style && 2 != e.cat_style) {
            var o = getApp().core.getStorageSync(getApp().const.CAT_LIST);
            o && a.setData({
                cat_list: o,
                current_cat: null
            }), getApp().request({
                url: getApp().api.default.cat_list,
                success: function(t) {
                    0 == t.code && (a.data.cat_list = t.data.list, 5 === e.cat_style && a.goodsAll({
                        currentTarget: {
                            dataset: {
                                index: 0
                            }
                        }
                    }), 4 !== e.cat_style && 2 !== e.cat_style || a.catItemClick({
                        currentTarget: {
                            dataset: {
                                index: 0
                            }
                        }
                    }), 1 !== e.cat_style && 3 !== e.cat_style || (a.setData({
                        cat_list: t.data.list,
                        current_cat: null
                    }), getApp().core.setStorageSync(getApp().const.CAT_LIST, t.data.list)));
                },
                complete: function() {
                    getApp().core.stopPullDownRefresh();
                }
            });
        } else a.setData({
            cat_list: a.data.cat_list,
            current_cat: a.data.current_cat
        });
    },
    childrenCat: function(t) {
        var a = this;
        e = !1, a.data.page, getApp().request({
            url: getApp().api.default.cat_list,
            success: function(e) {
                if (0 == e.code) {
                    var o = !0;
                    for (var i in e.data.list) for (var s in e.data.list[i].id == t && (o = !1, a.data.current_cat = e.data.list[i], 
                    0 < e.data.list[i].list.length ? (a.setData({
                        catheight: 100
                    }), a.firstcat({
                        currentTarget: {
                            dataset: {
                                index: 0
                            }
                        }
                    })) : a.firstcat({
                        currentTarget: {
                            dataset: {
                                index: 0
                            }
                        }
                    }, !1)), e.data.list[i].list) e.data.list[i].list[s].id == t && (o = !1, a.data.current_cat = e.data.list[i], 
                    a.goodsItem({
                        currentTarget: {
                            dataset: {
                                index: s
                            }
                        }
                    }, !1));
                    o && a.setData({
                        show_no_data_tip: !0
                    });
                }
            },
            complete: function() {
                getApp().core.stopPullDownRefresh(), getApp().core.createSelectorQuery().select("#cat").boundingClientRect().exec(function(t) {
                    a.setData({
                        height: t[0].height
                    });
                });
            }
        });
    },
    catItemClick: function(t) {
        var a = t.currentTarget.dataset.index, e = this.data.cat_list, o = null;
        for (var i in e) i == a ? (e[i].active = !0, o = e[i]) : e[i].active = !1;
        this.setData({
            cat_list: e,
            sub_cat_list_scroll_top: 0,
            current_cat: o
        });
    },
    firstcat: function(t) {
        var a = !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1], e = this, o = e.data.current_cat;
        e.setData({
            page: 1,
            goods_list: [],
            show_no_data_tip: !1,
            current_cat: a ? o : []
        }), e.list(o.id, 2);
    },
    goodsItem: function(t) {
        var a = !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1], e = this, o = t.currentTarget.dataset.index, i = e.data.current_cat, s = 0;
        for (var c in i.list) o == c ? (i.list[c].active = !0, s = i.list[c].id) : i.list[c].active = !1;
        e.setData({
            page: 1,
            goods_list: [],
            show_no_data_tip: !1,
            current_cat: a ? i : []
        }), e.list(s, 2);
    },
    goodsAll: function(t) {
        var e = this, o = t.currentTarget.dataset.index, i = e.data.cat_list, s = null;
        for (var c in i) c == o ? (i[c].active = !0, s = i[c]) : i[c].active = !1;
        if (e.setData({
            page: 1,
            goods_list: [],
            show_no_data_tip: !1,
            cat_list: i,
            current_cat: s
        }), void 0 === ("undefined" == typeof my ? "undefined" : a(my))) {
            var n = t.currentTarget.offsetLeft, r = e.data.scrollLeft;
            r = n - 80, e.setData({
                scrollLeft: r
            });
        } else i.forEach(function(a, o, s) {
            a.id == t.currentTarget.id && (1 <= o ? e.setData({
                toView: i[o - 1].id
            }) : e.setData({
                toView: i[o].id
            }));
        });
        e.list(s.id, 1), getApp().core.createSelectorQuery().select("#catall").boundingClientRect().exec(function(t) {
            e.setData({
                height: t[0].height
            });
        });
    },
    list: function(t, a) {
        var o = this;
        getApp().core.showLoading({
            title: "正在加载",
            mask: !0
        }), e = !1;
        var i = o.data.page || 2;
        getApp().request({
            url: getApp().api.default.goods_list,
            data: {
                cat_id: t,
                page: i
            },
            success: function(a) {
                0 == a.code && (getApp().core.hideLoading(), 0 == a.data.list.length && (e = !0), 
                o.setData({
                    page: i + 1
                }), o.setData({
                    goods_list: a.data.list
                }), o.setData({
                    cat_id: t
                })), o.setData({
                    show_no_data_tip: 0 == o.data.goods_list.length
                });
            },
            complete: function() {
                1 == a && getApp().core.createSelectorQuery().select("#catall").boundingClientRect().exec(function(t) {
                    o.setData({
                        height: t[0].height
                    });
                });
            }
        });
    },
    onReachBottom: function() {
        getApp().page.onReachBottom(this), e || 5 != getApp().core.getStorageSync(getApp().const.STORE).cat_style && -1 != this.data.cat_style || this.loadMoreGoodsList();
    },
    loadMoreGoodsList: function() {
        var t = this;
        if (!o) {
            t.setData({
                show_loading_bar: !0
            }), o = !0;
            var a = t.data.cat_id || "", i = t.data.page || 2;
            getApp().request({
                url: getApp().api.default.goods_list,
                data: {
                    page: i,
                    cat_id: a
                },
                success: function(a) {
                    0 == a.data.list.length && (e = !0);
                    var o = t.data.goods_list.concat(a.data.list);
                    t.setData({
                        goods_list: o,
                        page: i + 1
                    });
                },
                complete: function() {
                    o = !1, t.setData({
                        show_loading_bar: !1
                    });
                }
            });
        }
    }
});