var t, a, e = 0, o = !0, s = 1, n = !1, i = [], c = require("../../utils/qqmap-wx-jssdk.js");

Page({
    data: {
        WindowWidth: getApp().core.getSystemInfoSync().windowWidth,
        WindowHeight: getApp().core.getSystemInfoSync().windowHeight,
        left: 0,
        show_notice: -1,
        animationData: {},
        play: -1,
        time: 0,
        buy: !1,
        opendate: !1,
        goods: "",
        form: {
            number: 1
        },
        time_all: [],
        location: "定位中",
        mch_tab: 1,
        location_mask: 0,
        ostop: "0"
    },
    mchtab: function(t) {
        this.setData({
            mch_tab: t.currentTarget.dataset.tab,
            mch_list_data: this.data.mch_list["tab" + t.currentTarget.dataset.tab]
        });
    },
    settingcallback: function(t) {
        console.log(t), !0 === t.detail.authSetting["scope.userLocation"] && (this.setData({
            location_mask: 0
        }), this.onLoad());
    },
    onLoad: function(e) {
        console.log("index onload"), t = new c({
            key: "VZKBZ-MREK4-KN3UZ-XGRBN-G3GKV-SXFH4"
        });
        var o = this;
        getApp().request({
            url: getApp().api.order.order_scroll,
            success: function(t) {
                console.log("order_scroll:", t), o.setData({
                    scrollData: t.data
                });
                var e = 102 * -t.data.length;
                console.log("max_scroll_top:", e), o.setData({
                    ostop: 0
                }), clearInterval(a), a = setInterval(function() {
                    o.data.ostop--, console.log(e), o.data.ostop < e && (o.data.ostop = 0), o.setData({
                        ostop: o.data.ostop
                    });
                }, 30);
            }
        });
        var s = setInterval(function() {
            wx.getStorageSync("ACCESS_TOKEN") && (getApp().request({
                url: getApp().api.user.location_get,
                success: function(t) {
                    t.data.adcode ? (o.setData({
                        location: t.data.name
                    }), getApp().core.setStorageSync("adcode", t.data.adcode), o.getLocation(1)) : o.getLocation(0);
                }
            }), clearInterval(s));
        }, 200), n = setInterval(function() {
            var t = wx.getStorageSync("location"), a = wx.getStorageSync("adcode");
            wx.getStorageSync("ACCESS_TOKEN") && t && a && (getApp().request({
                url: getApp().api.default.index_mch,
                data: {
                    adcode: a,
                    location: t
                },
                success: function(t) {
                    o.setData({
                        mch_list: t.data,
                        mch_list_data: t.data.tab1
                    });
                }
            }), clearInterval(n));
        }, 200);
        getApp().page.onLoad(this, e), e.page_id || (e.page_id = -1), this.setData({
            options: e
        }), this.loadData(e);
    },
    getLocation: function(a) {
        var e = this;
        wx.getLocation({
            type: "wgs84",
            success: function(o) {
                console.log(o);
                var s = wx.getStorageSync("nolocsel");
                if (a && s) return !1;
                getApp().core.setStorageSync("location", {
                    latitude: o.latitude,
                    longitude: o.longitude
                }), t.reverseGeocoder({
                    coord_type: 1,
                    location: {
                        latitude: o.latitude,
                        longitude: o.longitude
                    },
                    success: function(t) {
                        console.log(t);
                        var o = "", s = t.result.ad_info.adcode;
                        o = t.result.address_component.district ? t.result.address_component.district : t.result.address_component.city, 
                        a ? wx.getStorageSync("adcode") != s && wx.showModal({
                            title: "地区提示",
                            content: "您当前所在的地区为" + o + "，是否切换地区？",
                            success: function(t) {
                                t.confirm ? getApp().request({
                                    url: getApp().api.user.location_save,
                                    data: {
                                        ad_code: s
                                    },
                                    method: "post",
                                    success: function(t) {
                                        console.log(t), getApp().core.setStorageSync("adcode", s), e.setData({
                                            adcode: s,
                                            location: o
                                        }), e.onLoad(e.data.options);
                                    }
                                }) : wx.setStorageSync("nolocsel", !0);
                            }
                        }) : (getApp().core.setStorageSync("adcode", s), e.setData({
                            adcode: s,
                            location: o
                        }));
                    },
                    fail: function(t) {
                        console.log(t), console.log("获取位置失败");
                    },
                    complete: function(t) {}
                });
            },
            complete: function(t) {
                console.log(t), wx.getSetting({
                    success: function(t) {
                        console.log(t.authSetting), !1 === t.authSetting["scope.userLocation"] && e.setData({
                            location_mask: 1
                        });
                    }
                });
            }
        });
    },
    toLocation: function() {
        wx.navigateTo({
            url: "/pages/location/location"
        });
    },
    toSearch: function() {
        wx.navigateTo({
            url: "/pages/search/search"
        });
    },
    suspension: function() {
        var t = this;
        e = setInterval(function() {
            getApp().request({
                url: getApp().api.default.buy_data,
                data: {
                    time: t.data.time
                },
                method: "POST",
                success: function(a) {
                    if (0 == a.code) {
                        var e = !1;
                        t.data.msgHistory == a.md5 && (e = !0);
                        var o = "", s = a.cha_time, n = Math.floor(s / 60 - 60 * Math.floor(s / 3600));
                        o = 0 == n ? s % 60 + "秒" : n + "分" + s % 60 + "秒", e ? t.setData({
                            buy: !1
                        }) : t.setData({
                            buy: {
                                time: o,
                                type: a.data.type,
                                url: a.data.url,
                                user: 5 <= a.data.user.length ? a.data.user.slice(0, 4) + "..." : a.data.user,
                                avatar_url: a.data.avatar_url,
                                address: 8 <= a.data.address.length ? a.data.address.slice(0, 7) + "..." : a.data.address,
                                content: a.data.content
                            },
                            msgHistory: a.md5
                        });
                    }
                },
                noHandlerFail: !0
            });
        }, 1e4);
    },
    loadData: function() {
        var t = this, a = {}, e = t.data.options;
        if (-1 != e.page_id) a.page_id = e.page_id; else {
            a.page_id = -1;
            var s = getApp().core.getStorageSync(getApp().const.PAGE_INDEX_INDEX);
            s && (s.act_modal_list = [], t.setData(s));
        }
        a.adcode = wx.getStorageSync("adcode"), a.location = wx.getStorageSync("location"), 
        getApp().request({
            url: getApp().api.default.index,
            data: a,
            success: function(a) {
                if (0 == a.code) {
                    if ("diy" == a.data.status) {
                        var s = a.data.act_modal_list;
                        -1 != e.page_id && (getApp().core.setNavigationBarTitle({
                            title: a.data.info
                        }), t.setData({
                            title: a.data.info
                        }));
                        for (var n = s.length - 1; 0 <= n; n--) (void 0 === s[n].status || 0 == s[n].status) && getApp().helper.inArray(s[n].page_id, i) && !t.data.user_info_show || 0 == s[n].show ? s.splice(n, 1) : i.push(s[n].page_id);
                        t.setData({
                            template: a.data.template,
                            act_modal_list: s,
                            time_all: a.data.time_all
                        }), t.setTime();
                    } else o ? t.data.user_info_show || (o = !1) : a.data.act_modal_list = [], t.setData(a.data), 
                    t.miaoshaTimer();
                    -1 == e.page_id && getApp().core.setStorageSync(getApp().const.PAGE_INDEX_INDEX, a.data);
                }
            },
            complete: function() {
                getApp().core.stopPullDownRefresh();
            }
        });
    },
    onShow: function() {
        console.log("index onshow");
        var t = this;
        getApp().page.onShow(this), require("./../../components/diy/diy.js").init(this), 
        getApp().getConfig(function(a) {
            var e = a.store;
            e && e.name && -1 == t.data.options.page_id && getApp().core.setNavigationBarTitle({
                title: e.name
            }), e && 1 === e.purchase_frame ? t.suspension(t.data.time) : t.setData({
                buy_user: ""
            });
        });
    },
    onPullDownRefresh: function() {
        getApp().getStoreData(), clearInterval(s), this.loadData();
    },
    onShareAppMessage: function(t) {
        getApp().page.onShareAppMessage(this);
        var a = this, e = getApp().getUser();
        return -1 != a.data.options.page_id ? {
            path: "/pages/index/index?user_id=" + e.id + "&page_id=" + a.data.options.page_id,
            title: a.data.title
        } : {
            path: "/pages/index/index?user_id=" + e.id,
            title: a.data.store.name
        };
    },
    showshop: function(t) {
        var a = this, e = t.currentTarget.dataset.id, o = t.currentTarget.dataset;
        getApp().request({
            url: getApp().api.default.goods,
            data: {
                id: e
            },
            success: function(t) {
                0 == t.code && a.setData({
                    data: o,
                    attr_group_list: t.data.attr_group_list,
                    goods: t.data,
                    showModal: !0
                });
            }
        });
    },
    miaoshaTimer: function() {
        var t = this;
        t.data.miaosha && 0 != t.data.miaosha.rest_time && (t.data.miaosha.ms_next || (s = setInterval(function() {
            0 < t.data.miaosha.rest_time ? (t.data.miaosha.rest_time = t.data.miaosha.rest_time - 1, 
            t.data.miaosha.times = t.setTimeList(t.data.miaosha.rest_time), t.setData({
                miaosha: t.data.miaosha
            })) : clearInterval(s);
        }, 1e3)));
    },
    onHide: function() {
        getApp().page.onHide(this), this.setData({
            play: -1
        }), clearInterval(e);
    },
    onUnload: function() {
        getApp().page.onUnload(this), this.setData({
            play: -1
        }), clearInterval(s), clearInterval(e);
    },
    showNotice: function(t) {
        console.log(t), this.setData({
            show_notice: t.currentTarget.dataset.index
        });
    },
    closeNotice: function() {
        this.setData({
            show_notice: -1
        });
    },
    to_dial: function() {
        var t = this.data.store.contact_tel;
        getApp().core.makePhoneCall({
            phoneNumber: t
        });
    },
    closeActModal: function() {
        var t = this, a = t.data.act_modal_list;
        for (var e in a) {
            var o = parseInt(e);
            a[o].show && (a[o].show = !1);
            break;
        }
        t.setData({
            act_modal_list: a
        }), setTimeout(function() {
            for (var e in a) if (a[e].show) {
                a = a.splice(e, 1).concat(a);
                break;
            }
            t.setData({
                act_modal_list: a
            });
        }, 500);
    },
    naveClick: function(t) {
        getApp().navigatorClick(t, this);
    },
    onPageScroll: function(t) {
        var a = this;
        if (!n && -1 != a.data.play) {
            var e = getApp().core.getSystemInfoSync().windowHeight;
            "undefined" == typeof my ? getApp().core.createSelectorQuery().select(".video").fields({
                rect: !0
            }, function(t) {
                (t.top <= -200 || t.top >= e - 57) && a.setData({
                    play: -1
                });
            }).exec() : getApp().core.createSelectorQuery().select(".video").boundingClientRect().scrollOffset().exec(function(t) {
                (t[0].top <= -200 || t[0].top >= e - 57) && a.setData({
                    play: -1
                });
            });
        }
    },
    fullscreenchange: function(t) {
        n = !!t.detail.fullScreen;
    }
});