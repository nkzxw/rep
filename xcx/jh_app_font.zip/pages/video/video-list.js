var t = getApp(), a = t.api, o = !1, e = !1;

Page({
    data: {
        page: 1,
        video_list: [],
        url: "",
        hide: "hide",
        show: !1,
        animationData: {}
    },
    onLoad: function(a) {
        t.page.onLoad(this, a), this.loadMoreGoodsList(), e = o = !1;
    },
    onReady: function() {},
    onShow: function() {
        t.page.onShow(this);
    },
    onHide: function() {
        t.page.onHide(this);
    },
    onUnload: function() {
        t.page.onUnload(this);
    },
    onPullDownRefresh: function() {},
    loadMoreGoodsList: function() {
        var i = this;
        if (!o) {
            i.setData({
                show_loading_bar: !0
            }), o = !0;
            var n = i.data.page;
            t.request({
                url: a.default.video_list,
                data: {
                    page: n
                },
                success: function(t) {
                    0 == t.data.list.length && (e = !0);
                    var a = i.data.video_list.concat(t.data.list);
                    i.setData({
                        video_list: a,
                        page: n + 1
                    });
                },
                complete: function() {
                    o = !1, i.setData({
                        show_loading_bar: !1
                    });
                }
            });
        }
    },
    play: function(t) {
        var a = t.currentTarget.dataset.index;
        getApp().core.createVideoContext("video_" + this.data.show_video).pause(), this.setData({
            show_video: a,
            show: !0
        });
    },
    onReachBottom: function() {
        e || this.loadMoreGoodsList();
    },
    more: function(t) {
        var a = this, o = t.target.dataset.index, e = a.data.video_list, i = getApp().core.createAnimation({
            duration: 1e3,
            timingFunction: "ease"
        });
        this.animation = i, -1 != e[o].show ? (i.rotate(0).step(), e[o].show = -1) : (i.rotate(0).step(), 
        e[o].show = 0), a.setData({
            video_list: e,
            animationData: this.animation.export()
        });
    }
});