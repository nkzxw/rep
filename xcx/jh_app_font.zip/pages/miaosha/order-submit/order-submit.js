var t = "", e = "", a = require("../../../utils/helper.js");

Page({
    data: {
        total_price: 0,
        address: null,
        express_price: 0,
        content: "",
        offline: 0,
        express_price_1: 0,
        name: "",
        mobile: "",
        integral_radio: 1,
        new_total_price: 0,
        show_card: !1,
        payment: -1,
        show_payment: !1
    },
    onLoad: function(t) {
        getApp().page.onLoad(this, t);
        var e = a.formatData(new Date());
        getApp().core.removeStorageSync(getApp().const.INPUT_DATA), this.setData({
            options: t,
            time: e
        });
    },
    bindkeyinput: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    KeyName: function(t) {
        this.setData({
            name: t.detail.value
        });
    },
    KeyMobile: function(t) {
        this.setData({
            mobile: t.detail.value
        });
    },
    getOffline: function(t) {
        var e = this.data.express_price, a = this.data.express_price_1;
        1 == t.target.dataset.index ? this.setData({
            offline: 1,
            express_price: 0,
            express_price_1: e
        }) : this.setData({
            offline: 0,
            express_price: a
        }), this.getPrice();
    },
    dingwei: function() {
        var a = this;
        getApp().getauth({
            content: "需要获取您的地理位置授权，请到小程序设置中打开授权",
            author: "scope.userLocation",
            success: function(s) {
                s && (s.authSetting["scope.userLocation"] ? getApp().core.chooseLocation({
                    success: function(s) {
                        t = s.longitude, e = s.latitude, a.setData({
                            location: s.address
                        });
                    }
                }) : getApp().core.showToast({
                    title: "您取消了授权",
                    image: "/images/icon-warning.png"
                }));
            }
        });
    },
    orderSubmit: function(t) {
        var e = this, a = e.data.offline, s = {};
        if (0 == a) {
            if (!e.data.address || !e.data.address.id) return void getApp().core.showToast({
                title: "请选择收货地址",
                image: "/images/icon-warning.png"
            });
            s.address_id = e.data.address.id;
        } else {
            if (s.address_name = e.data.name, s.address_mobile = e.data.mobile, !e.data.shop.id) return void getApp().core.showModal({
                title: "警告",
                content: "请选择门店",
                showCancel: !1
            });
            if (s.shop_id = e.data.shop.id, !s.address_name || null == s.address_name) return void e.showToast({
                title: "请填写收货人",
                image: "/images/icon-warning.png"
            });
            if (!s.address_mobile || null == s.address_mobile) return void e.showToast({
                title: "请填写联系方式",
                image: "/images/icon-warning.png"
            });
        }
        if (s.offline = a, -1 == e.data.payment) return e.setData({
            show_payment: !0
        }), !1;
        e.data.cart_id_list && (s.cart_id_list = JSON.stringify(e.data.cart_id_list)), e.data.goods_info && (s.goods_info = JSON.stringify(e.data.goods_info)), 
        e.data.picker_coupon && (s.user_coupon_id = e.data.picker_coupon.user_coupon_id), 
        e.data.content && (s.content = e.data.content), 1 == e.data.integral_radio ? s.use_integral = 1 : s.use_integral = 2, 
        s.payment = e.data.payment, s.formId = t.detail.formId, e.order_submit(s, "ms");
    },
    onReady: function(t) {
        getApp().page.onReady(this);
    },
    onShow: function(t) {
        getApp().page.onShow(this);
        var e = this, a = getApp().core.getStorageSync(getApp().const.PICKER_ADDRESS);
        a && (e.setData({
            address: a,
            name: a.name,
            mobile: a.mobile
        }), getApp().core.removeStorageSync(getApp().const.PICKER_ADDRESS), e.getInputData()), 
        e.getOrderData(e.data.options);
    },
    getOrderData: function(a) {
        var s = this, o = "";
        s.data.address && s.data.address.id && (o = s.data.address.id), a.goods_info && (getApp().core.showLoading({
            title: "正在加载",
            mask: !0
        }), getApp().request({
            url: getApp().api.miaosha.submit_preview,
            data: {
                goods_info: a.goods_info,
                address_id: o,
                longitude: t,
                latitude: e
            },
            success: function(t) {
                if (getApp().core.hideLoading(), 0 == t.code) {
                    var e = t.data.shop_list, a = {};
                    1 == e.length && (a = e[0]);
                    var o = getApp().core.getStorageSync(getApp().const.INPUT_DATA);
                    o || (o = {
                        address: t.data.address,
                        name: t.data.address ? t.data.address.name : "",
                        mobile: t.data.address ? t.data.address.mobile : "",
                        shop: a
                    }, 0 < t.data.pay_type_list.length && (o.payment = t.data.pay_type_list[0].payment, 
                    1 < t.data.pay_type_list.length && (o.payment = -1))), o.total_price = t.data.total_price, 
                    o.level_price = t.data.level_price, o.is_level = t.data.is_level, o.goods_list = t.data.list, 
                    o.goods_info = t.data.goods_info, o.express_price = parseFloat(t.data.express_price), 
                    o.coupon_list = t.data.coupon_list, o.shop_list = t.data.shop_list, o.send_type = t.data.send_type, 
                    o.level = t.data.level, o.integral = t.data.integral, o.new_total_price = t.data.level_price, 
                    o.is_payment = t.data.is_payment, o.is_coupon = t.data.list[0].coupon, o.is_discount = t.data.list[0].is_discount, 
                    o.is_area = t.data.is_area, o.pay_type_list = t.data.pay_type_list, s.setData(o), 
                    s.getInputData(), 1 == t.data.send_type && s.setData({
                        offline: 0
                    }), 2 == t.data.send_type && s.setData({
                        offline: 1
                    }), s.getPrice();
                }
                1 == t.code && getApp().core.showModal({
                    title: "提示",
                    content: t.msg,
                    showCancel: !1,
                    confirmText: "返回",
                    success: function(t) {
                        t.confirm && (1 == getCurrentPages().length ? getApp().core.redirectTo({
                            url: "/pages/index/index"
                        }) : getApp().core.navigateBack({
                            delta: 1
                        }));
                    }
                });
            }
        }));
    },
    copyText: function(t) {
        var e = t.currentTarget.dataset.text;
        e && getApp().core.setClipboardData({
            data: e,
            success: function() {
                self.showToast({
                    title: "已复制内容"
                });
            },
            fail: function() {
                self.showToast({
                    title: "复制失败",
                    image: "/images/icon-warning.png"
                });
            }
        });
    },
    showCouponPicker: function() {
        var t = this;
        t.getInputData(), t.data.coupon_list && 0 < t.data.coupon_list.length && t.setData({
            show_coupon_picker: !0
        });
    },
    pickCoupon: function(t) {
        var e = getApp().core.getStorageSync(getApp().const.INPUT_DATA);
        getApp().core.removeStorageSync(getApp().const.INPUT_DATA);
        var a = t.currentTarget.dataset.index;
        e.show_coupon_picker = !1, e.picker_coupon = "-1" != a && -1 != a && this.data.coupon_list[a], 
        this.setData(e), this.getPrice();
    },
    numSub: function(t, e, a) {
        return 100;
    },
    showShop: function(t) {
        var e = this;
        e.getInputData(), e.dingwei(), e.data.shop_list && 1 <= e.data.shop_list.length && e.setData({
            show_shop: !0
        });
    },
    pickShop: function(t) {
        var e = t.currentTarget.dataset.index, a = getApp().core.getStorageSync(getApp().const.INPUT_DATA);
        getApp().core.removeStorageSync(getApp().const.INPUT_DATA), a.show_shop = !1, a.shop = "-1" != e && -1 != e && this.data.shop_list[e], 
        this.setData(a), this.getPrice();
    },
    integralSwitchChange: function(t) {
        0 != t.detail.value ? this.setData({
            integral_radio: 1
        }) : this.setData({
            integral_radio: 2
        }), this.getPrice();
    },
    integration: function(t) {
        var e = this.data.integral.integration;
        getApp().core.showModal({
            title: "积分使用规则",
            content: e,
            showCancel: !1,
            confirmText: "我知道了",
            confirmColor: "#ff4544",
            success: function(t) {
                t.confirm;
            }
        });
    },
    getPrice: function() {
        var t = this, e = (t.data.total_price, parseFloat(t.data.level_price)), a = t.data.express_price, s = t.data.picker_coupon, o = t.data.integral, i = t.data.integral_radio, n = (t.data.level, 
        t.data.is_level, t.data.offline);
        s && (e -= s.sub_price), o && 1 == i && (e -= parseFloat(o.forehead)), e <= .01 && (e = .01), 
        0 == n && (console.log(a), e += a, console.log(e)), e = parseFloat(e), t.setData({
            new_total_price: e.toFixed(2)
        });
    },
    cardDel: function() {
        this.setData({
            show_card: !1
        }), getApp().core.redirectTo({
            url: "/pages/order/order?status=1"
        });
    },
    cardTo: function() {
        this.setData({
            show_card: !1
        }), getApp().core.redirectTo({
            url: "/pages/card/card"
        });
    },
    formInput: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.form, s = a.list;
        s[e].default = t.detail.value, a.list = s, this.setData({
            form: a
        });
    },
    selectForm: function(t) {
        var e = t.currentTarget.dataset.index, a = t.currentTarget.dataset.k, s = this.data.form, o = s.list;
        if ("radio" == o[e].type) {
            var i = o[e].default_list;
            for (var n in i) n == a ? i[a].is_selected = 1 : i[n].is_selected = 0;
            o[e].default_list = i;
        }
        "checkbox" == o[e].type && (1 == (i = o[e].default_list)[a].is_selected ? i[a].is_selected = 0 : i[a].is_selected = 1, 
        o[e].default_list = i), s.list = o, this.setData({
            form: s
        });
    },
    showPayment: function() {
        this.setData({
            show_payment: !0
        });
    },
    payPicker: function(t) {
        var e = t.currentTarget.dataset.index;
        this.setData({
            payment: e,
            show_payment: !1
        });
    },
    payClose: function() {
        this.setData({
            show_payment: !1
        });
    },
    getInputData: function() {
        var t = this, e = {
            address: t.data.address,
            name: t.data.name,
            mobile: t.data.mobile,
            content: t.data.content,
            payment: t.data.payment,
            shop: t.data.shop
        };
        getApp().core.setStorageSync(getApp().const.INPUT_DATA, e);
    },
    onHide: function(t) {
        getApp().page.onHide(this), this.getInputData();
    },
    onUnload: function(t) {
        getApp().page.onUnload(this), getApp().core.removeStorageSync(getApp().const.INPUT_DATA);
    }
});