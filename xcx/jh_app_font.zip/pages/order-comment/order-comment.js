getApp(), getApp().api;

Page({
    data: {
        goods_list: []
    },
    onLoad: function(t) {
        getApp().page.onLoad(this, t);
        var e = this;
        if (t.inId) var o = {
            order_id: t.inId,
            type: "IN"
        }; else o = {
            order_id: t.id,
            type: "mall"
        };
        e.setData({
            order_id: o.order_id,
            type: o.type
        }), getApp().core.showLoading({
            title: "正在加载",
            mask: !0
        }), getApp().request({
            url: getApp().api.order.comment_preview,
            data: o,
            success: function(t) {
                if (getApp().core.hideLoading(), 1 == t.code && getApp().core.showModal({
                    title: "提示",
                    content: t.msg,
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && getApp().core.navigateBack();
                    }
                }), 0 == t.code) {
                    for (var o in t.data.goods_list) t.data.goods_list[o].score = 3, t.data.goods_list[o].content = "", 
                    t.data.goods_list[o].pic_list = [], t.data.goods_list[o].uploaded_pic_list = [];
                    e.setData({
                        goods_list: t.data.goods_list
                    });
                }
            }
        });
    },
    setScore: function(t) {
        var e = t.currentTarget.dataset.index, o = t.currentTarget.dataset.score, a = this.data.goods_list;
        a[e].score = o, this.setData({
            goods_list: a
        });
    },
    contentInput: function(t) {
        var e = this, o = t.currentTarget.dataset.index;
        e.data.goods_list[o].content = t.detail.value, e.setData({
            goods_list: e.data.goods_list
        });
    },
    chooseImage: function(t) {
        var e = this, o = t.currentTarget.dataset.index, a = e.data.goods_list, i = a[o].pic_list.length;
        getApp().core.chooseImage({
            count: 6 - i,
            success: function(t) {
                a[o].pic_list = a[o].pic_list.concat(t.tempFilePaths), e.setData({
                    goods_list: a
                });
            }
        });
    },
    deleteImage: function(t) {
        var e = t.currentTarget.dataset.index, o = t.currentTarget.dataset.picIndex, a = this.data.goods_list;
        a[e].pic_list.splice(o, 1), this.setData({
            goods_list: a
        });
    },
    commentSubmit: function(t) {
        var e = this;
        getApp().core.showLoading({
            title: "正在提交",
            mask: !0
        });
        var o = e.data.goods_list, a = (getApp().siteInfo, {});
        !function t(i) {
            if (i != o.length) {
                var s = 0;
                if (!o[i].pic_list.length || 0 == o[i].pic_list.length) return t(i + 1);
                for (var n in o[i].pic_list) !function(e) {
                    getApp().core.uploadFile({
                        url: getApp().api.default.upload_image,
                        name: "image",
                        formData: a,
                        filePath: o[i].pic_list[e],
                        complete: function(a) {
                            if (a.data) {
                                var n = JSON.parse(a.data);
                                0 == n.code && (o[i].uploaded_pic_list[e] = n.data.url);
                            }
                            if (++s == o[i].pic_list.length) return t(i + 1);
                        }
                    });
                }(n);
            } else getApp().request({
                url: getApp().api.order.comment,
                method: "post",
                data: {
                    order_id: e.data.order_id,
                    goods_list: JSON.stringify(o),
                    type: e.data.type
                },
                success: function(t) {
                    getApp().core.hideLoading(), 0 == t.code && getApp().core.showModal({
                        title: "提示",
                        content: t.msg,
                        showCancel: !1,
                        success: function(e) {
                            e.confirm && ("IN" == t.type ? getApp().core.redirectTo({
                                url: "/pages/integral-mall/order/order?status=3"
                            }) : getApp().core.redirectTo({
                                url: "/pages/order/order?status=3"
                            }));
                        }
                    }), 1 == t.code && getApp().core.showToast({
                        title: t.msg,
                        image: "/images/icon-warning.png"
                    });
                }
            });
        }(0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});