Page({
    data: {},
    onLoad: function(a) {
        getApp().page.onLoad(this, a);
    }
});