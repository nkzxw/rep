Page({
    data: {
        mch_id: 0
    },
    onLoad: function(t) {
        this.setData({
            options: t
        }), getApp().page.onLoad(this, t);
    },
    onShow: function() {
        getApp().page.onShow(this);
        var t = this;
        getApp().core.showLoading({
            mask: !0
        }), getApp().request({
            url: getApp().api.default.coupon_list,
            data: {
                mch_id: t.data.options.mch_id
            },
            success: function(o) {
                0 == o.code && t.setData({
                    coupon_list: o.data.list
                });
            },
            complete: function() {
                getApp().core.hideLoading();
            }
        });
    },
    receive: function(t) {
        var o = this, e = t.target.dataset.index;
        getApp().core.showLoading({
            mask: !0
        }), o.hideGetCoupon || (o.hideGetCoupon = function(t) {
            var e = t.currentTarget.dataset.url || !1;
            o.setData({
                get_coupon_list: null
            }), e && getApp().core.navigateTo({
                url: e
            });
        }), getApp().request({
            url: getApp().api.coupon.receive,
            data: {
                id: e
            },
            success: function(t) {
                0 == t.code && o.setData({
                    get_coupon_list: t.data.list,
                    coupon_list: t.data.coupon_list
                });
            },
            complete: function() {
                getApp().core.hideLoading();
            }
        });
    },
    closeCouponBox: function(t) {
        this.setData({
            get_coupon_list: ""
        });
    },
    goodsList: function(t) {
        var o = t.currentTarget.dataset.goods, e = [];
        for (var a in o) e.push(o[a].id);
        getApp().core.navigateTo({
            url: "/pages/list/list?goods_id=" + e
        });
    }
});