var t = require("../../../components/shopping_cart/shopping_cart.js"), o = require("../../../components/specifications_model/specifications_model.js");

Page({
    data: {
        quick_list: [],
        goods_list: [],
        carGoods: [],
        currentGood: {},
        checked_attr: [],
        checkedGood: [],
        attr_group_list: [],
        temporaryGood: {
            price: 0,
            num: 0,
            use_attr: 1
        },
        check_goods_price: 0,
        showModal: !1,
        checked: !1,
        cat_checked: !1,
        color: "",
        total: {
            total_price: 0,
            total_num: 0
        }
    },
    onLoad: function(t) {
        getApp().page.onLoad(this, t);
    },
    onShow: function() {
        getApp().page.onShow(this), t.init(this), o.init(this, t), this.loadData();
    },
    onHide: function() {
        getApp().page.onHide(this), t.saveItemData(this);
    },
    onUnload: function() {
        getApp().page.onUnload(this), t.saveItemData(this);
    },
    loadData: function(t) {
        var o = this, e = getApp().core.getStorageSync(getApp().const.ITEM);
        o.setData({
            total: void 0 !== e.total ? e.total : {
                total_num: 0,
                total_price: 0
            },
            carGoods: void 0 !== e.carGoods ? e.carGoods : []
        }), getApp().core.showLoading({
            title: "加载中"
        }), getApp().request({
            url: getApp().api.quick.quick,
            success: function(t) {
                if (getApp().core.hideLoading(), 0 == t.code) {
                    var a = t.data.list, s = [], i = [], c = [];
                    for (var d in a) if (0 < a[d].goods.length) for (var n in i.push(a[d]), a[d].goods) {
                        var r = !0;
                        if (getApp().helper.inArray(a[d].goods[n].id, c) && (a[d].goods.splice(n, 1), r = !1), 
                        r) {
                            var p = o.data.carGoods;
                            for (var g in p) e.carGoods[g].goods_id === parseInt(a[d].goods[n].id) && (a[d].goods[n].num = a[d].goods[n].num ? a[d].goods[n].num : 0, 
                            a[d].goods[n].num += e.carGoods[g].num);
                            parseInt(a[d].goods[n].hot_cakes) && s.push(a[d].goods[n]), c.push(a[d].goods[n].id);
                        }
                    }
                    o.setData({
                        quick_hot_goods_lists: s,
                        quick_list: i
                    });
                }
            }
        });
    },
    get_goods_info: function(t) {
        var o = this, e = o.data.carGoods, a = o.data.total, s = o.data.quick_hot_goods_lists, i = o.data.quick_list, c = {
            carGoods: e,
            total: a,
            quick_hot_goods_lists: s,
            check_num: o.data.check_num,
            quick_list: i
        };
        getApp().core.setStorageSync(getApp().const.ITEM, c);
        var d = t.currentTarget.dataset.id;
        getApp().core.navigateTo({
            url: "/pages/goods/goods?id=" + d + "&quick=1"
        });
    },
    selectMenu: function(t) {
        var o = t.currentTarget.dataset, e = this.data.quick_list;
        if ("hot_cakes" == o.tag) for (var a = !0, s = e.length, i = 0; i < s; i++) e[i].cat_checked = !1; else {
            var c = o.index;
            for (s = e.length, i = 0; i < s; i++) e[i].cat_checked = !1, e[i].id == e[c].id && (e[i].cat_checked = !0);
            a = !1;
        }
        this.setData({
            toView: o.tag,
            quick_list: e,
            cat_checked: a
        });
    },
    onShareAppMessage: function(t) {
        getApp().page.onShareAppMessage(this);
        var o = this;
        return {
            path: "/pages/quick-purchase/index/index?user_id=" + getApp().core.getStorageSync(getApp().const.USER_INFO).id,
            success: function(t) {
                1 == ++share_count && o.shareSendCoupon(o);
            }
        };
    },
    close_box: function(t) {
        this.setData({
            showModal: !1
        });
    },
    hideModal: function() {
        this.setData({
            showModal: !1
        });
    }
});