Page({
    data: {
        goods_list: []
    },
    onLoad: function(t) {
        getApp().page.onLoad(this, t);
        var e = this;
        e.setData({
            order_id: t.id
        }), getApp().core.showLoading({
            title: "正在加载",
            mask: !0
        }), getApp().request({
            url: getApp().api.group.order.comment_preview,
            data: {
                order_id: t.id
            },
            success: function(t) {
                if (getApp().core.hideLoading(), 1 == t.code && getApp().core.showModal({
                    title: "提示",
                    content: t.msg,
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && getApp().core.navigateBack();
                    }
                }), 0 == t.code) {
                    for (var o in t.data.goods_list) t.data.goods_list[o].score = 3, t.data.goods_list[o].content = "", 
                    t.data.goods_list[o].pic_list = [], t.data.goods_list[o].uploaded_pic_list = [];
                    e.setData({
                        goods_list: t.data.goods_list
                    });
                }
            }
        });
    },
    setScore: function(t) {
        var e = t.currentTarget.dataset.index, o = t.currentTarget.dataset.score, a = this.data.goods_list;
        a[e].score = o, this.setData({
            goods_list: a
        });
    },
    contentInput: function(t) {
        var e = this, o = t.currentTarget.dataset.index;
        e.data.goods_list[o].content = t.detail.value, e.setData({
            goods_list: e.data.goods_list
        });
    },
    chooseImage: function(t) {
        var e = this, o = t.currentTarget.dataset.index, a = e.data.goods_list, i = a[o].pic_list.length;
        getApp().core.chooseImage({
            count: 6 - i,
            success: function(t) {
                a[o].pic_list = a[o].pic_list.concat(t.tempFilePaths), e.setData({
                    goods_list: a
                });
            }
        });
    },
    deleteImage: function(t) {
        var e = t.currentTarget.dataset.index, o = t.currentTarget.dataset.picIndex, a = this.data.goods_list;
        a[e].pic_list.splice(o, 1), this.setData({
            goods_list: a
        });
    },
    commentSubmit: function(t) {
        var e = this;
        getApp().core.showLoading({
            title: "正在提交",
            mask: !0
        });
        var o = e.data.goods_list;
        !function t(a) {
            if (a != o.length) {
                var i = 0;
                if (!o[a].pic_list.length || 0 == o[a].pic_list.length) return t(a + 1);
                for (var s in o[a].pic_list) !function(e) {
                    getApp().core.uploadFile({
                        url: getApp().api.default.upload_image,
                        name: "image",
                        filePath: o[a].pic_list[e],
                        complete: function(s) {
                            if (s.data) {
                                var n = JSON.parse(s.data);
                                0 == n.code && (o[a].uploaded_pic_list[e] = n.data.url);
                            }
                            if (++i == o[a].pic_list.length) return t(a + 1);
                        }
                    });
                }(s);
            } else getApp().request({
                url: getApp().api.group.order.comment,
                method: "post",
                data: {
                    order_id: e.data.order_id,
                    goods_list: JSON.stringify(o)
                },
                success: function(t) {
                    getApp().core.hideLoading(), 0 == t.code && getApp().core.showModal({
                        title: "提示",
                        content: t.msg,
                        showCancel: !1,
                        success: function(t) {
                            t.confirm && getApp().core.redirectTo({
                                url: "/pages/pt/order/order?status=2"
                            });
                        }
                    }), 1 == t.code && getApp().core.showToast({
                        title: t.msg,
                        image: "/images/icon-warning.png"
                    });
                }
            });
        }(0);
    },
    onReady: function(t) {
        getApp().page.onReady(this);
    },
    onShow: function(t) {
        getApp().page.onShow(this);
    },
    onHide: function(t) {
        getApp().page.onHide(this);
    },
    onUnload: function(t) {
        getApp().page.onUnload(this);
    },
    onPullDownRefresh: function(t) {
        getApp().page.onPullDownRefresh(this);
    },
    onReachBottom: function(t) {
        getApp().page.onReachBottom(this);
    }
});