var t = "", a = "";

Page({
    data: {
        address: null,
        offline: 1,
        payment: -1,
        show_payment: !1
    },
    onLoad: function(t) {
        getApp().page.onLoad(this, t), getApp().core.removeStorageSync(getApp().const.INPUT_DATA);
        var a, e = t.goods_info, o = JSON.parse(e);
        a = 3 == o.deliver_type || 1 == o.deliver_type ? 1 : 2, this.setData({
            options: t,
            type: o.type,
            offline: a,
            parent_id: o.parent_id ? o.parent_id : 0
        });
    },
    onReady: function(t) {
        getApp().page.onReady(this);
    },
    onShow: function(t) {
        getApp().page.onShow(this);
        var a = this, e = getApp().core.getStorageSync(getApp().const.PICKER_ADDRESS);
        e && (a.setData({
            address: e,
            name: e.name,
            mobile: e.mobile
        }), getApp().core.removeStorageSync(getApp().const.PICKER_ADDRESS), a.getInputData()), 
        a.getOrderData(a.data.options);
    },
    onHide: function(t) {
        getApp().page.onHide(this), this.getInputData();
    },
    onUnload: function(t) {
        getApp().page.onUnload(this), getApp().core.removeStorageSync(getApp().const.INPUT_DATA);
    },
    onPullDownRefresh: function(t) {
        getApp().page.onPullDownRefresh(this);
    },
    onReachBottom: function(t) {
        getApp().page.onReachBottom(this);
    },
    getOrderData: function(e) {
        var o = this, s = "";
        o.data.address && o.data.address.id && (s = o.data.address.id), e.goods_info && (getApp().core.showLoading({
            title: "正在加载",
            mask: !0
        }), getApp().request({
            url: getApp().api.group.submit_preview,
            data: {
                goods_info: e.goods_info,
                group_id: e.group_id,
                address_id: s,
                type: o.data.type,
                longitude: t,
                latitude: a
            },
            success: function(t) {
                if (getApp().core.hideLoading(), 0 == t.code) {
                    var a = 0;
                    for (var e in t.data.list) a = t.data.list[e].level_price;
                    if (2 == o.data.offline) var s = parseFloat(0 < a - t.data.colonel ? a - t.data.colonel : .01), n = 0; else s = parseFloat(0 < a - t.data.colonel ? a - t.data.colonel : .01) + t.data.express_price, 
                    n = parseFloat(t.data.express_price);
                    var i = getApp().core.getStorageSync(getApp().const.INPUT_DATA);
                    getApp().core.removeStorageSync(getApp().const.INPUT_DATA), i || (i = {
                        address: t.data.address,
                        name: t.data.address ? t.data.address.name : "",
                        mobile: t.data.address ? t.data.address.mobile : ""
                    }, 0 < t.data.pay_type_list.length && (i.payment = t.data.pay_type_list[0].payment, 
                    1 < t.data.pay_type_list.length && (i.payment = -1)), t.data.shop && (i.shop = t.data.shop), 
                    t.data.shop_list && 1 == t.data.shop_list.length && (i.shop = t.data.shop_list[0])), 
                    i.total_price = t.data.total_price, i.total_price_1 = s.toFixed(2), i.goods_list = t.data.list, 
                    i.goods_info = t.data.goods_info, i.express_price = n, i.send_type = t.data.send_type, 
                    i.colonel = t.data.colonel, i.pay_type_list = t.data.pay_type_list, i.shop_list = t.data.shop_list, 
                    i.res = t.data, i.is_area = t.data.is_area, o.setData(i), o.getInputData();
                }
                1 == t.code && getApp().core.showModal({
                    title: "提示",
                    content: t.msg,
                    showCancel: !1,
                    confirmText: "返回",
                    success: function(t) {
                        t.confirm && getApp().core.navigateBack({
                            delta: 1
                        });
                    }
                });
            }
        }));
    },
    bindkeyinput: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    orderSubmit: function(t) {
        var a = this, e = {}, o = a.data.offline;
        if (1 == (e.offline = o)) {
            if (!a.data.address || !a.data.address.id) return void getApp().core.showToast({
                title: "请选择收货地址",
                image: "/images/icon-warning.png"
            });
            e.address_id = a.data.address.id;
        } else {
            if (e.address_name = a.data.name, e.address_mobile = a.data.mobile, !a.data.shop.id) return void getApp().core.showToast({
                title: "请选择核销门店",
                image: "/images/icon-warning.png"
            });
            if (e.shop_id = a.data.shop.id, !e.address_name || null == e.address_name) return void getApp().core.showToast({
                title: "请填写收货人",
                image: "/images/icon-warning.png"
            });
            if (!e.address_mobile || null == e.address_mobile) return void getApp().core.showToast({
                title: "请填写联系方式",
                image: "/images/icon-warning.png"
            });
        }
        if (-1 == a.data.payment) return a.setData({
            show_payment: !0
        }), !1;
        a.data.goods_info && (e.goods_info = JSON.stringify(a.data.goods_info)), a.data.picker_coupon && (e.user_coupon_id = a.data.picker_coupon.user_coupon_id), 
        a.data.content && (e.content = a.data.content), a.data.type && (e.type = a.data.type), 
        a.data.parent_id && (e.parent_id = a.data.parent_id), e.payment = a.data.payment, 
        e.formId = t.detail.formId, a.order_submit(e, "pt");
    },
    KeyName: function(t) {
        this.setData({
            name: t.detail.value
        });
    },
    KeyMobile: function(t) {
        this.setData({
            mobile: t.detail.value
        });
    },
    getOffline: function(t) {
        var a = this, e = t.target.dataset.index, o = parseFloat(0 < a.data.res.total_price - a.data.res.colonel ? a.data.res.total_price - a.data.res.colonel : .01) + a.data.res.express_price;
        if (1 == e) this.setData({
            offline: 1,
            express_price: a.data.res.express_price,
            total_price_1: o.toFixed(2)
        }); else {
            var s = (a.data.total_price_1 - a.data.express_price).toFixed(2);
            this.setData({
                offline: 2,
                express_price: 0,
                total_price_1: s
            });
        }
    },
    showShop: function(t) {
        var a = this;
        a.getInputData(), a.dingwei(), a.data.shop_list && 1 <= a.data.shop_list.length && a.setData({
            show_shop: !0
        });
    },
    dingwei: function() {
        var e = this;
        getApp().getauth({
            content: "需要获取您的地理位置授权，请到小程序设置中打开授权",
            author: "scope.userLocation",
            success: function(o) {
                o && (o.authSetting["scope.userLocation"] ? getApp().core.chooseLocation({
                    success: function(o) {
                        t = o.longitude, a = o.latitude, e.setData({
                            location: o.address
                        });
                    }
                }) : getApp().core.showToast({
                    title: "您取消了授权",
                    image: "/images/icon-warning.png"
                }));
            }
        });
    },
    pickShop: function(t) {
        var a = getApp().core.getStorageSync(getApp().const.INPUT_DATA), e = t.currentTarget.dataset.index;
        a.show_shop = !1, a.shop = "-1" != e && -1 != e && this.data.shop_list[e], this.setData(a);
    },
    showPayment: function() {
        this.setData({
            show_payment: !0
        });
    },
    payPicker: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            payment: a,
            show_payment: !1
        });
    },
    payClose: function() {
        this.setData({
            show_payment: !1
        });
    },
    getInputData: function() {
        var t = this, a = {
            address: t.data.address,
            name: t.data.name,
            mobile: t.data.mobile,
            payment: t.data.payment,
            content: t.data.content,
            shop: t.data.shop
        };
        getApp().core.setStorageSync(getApp().const.INPUT_DATA, a);
    }
});