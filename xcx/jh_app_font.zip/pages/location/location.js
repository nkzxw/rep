var t, e = require("../../components/area-picker/area-picker.js"), o = (getApp(), 
getApp().api, require("../../utils/qqmap-wx-jssdk.js"));

Page({
    data: {
        ad_name: "正在获取定位信息..."
    },
    formSubmit: function(t) {
        console.log("form发生了submit事件，携带数据为：", t.detail.value), getApp().request({
            url: getApp().api.user.location_save,
            data: t.detail.value,
            method: "post",
            success: function(t) {
                console.log(t), 0 == t.code && (getApp().core.setStorageSync("adcode", t.data), 
                getApp().core.setStorageSync("nolocsel", !0), wx.navigateTo({
                    url: "/pages/index/index"
                }));
            }
        });
    },
    onLoad: function(i) {
        wx.setNavigationBarTitle({
            title: "选择地区"
        });
        var n = this;
        t = new o({
            key: "VZKBZ-MREK4-KN3UZ-XGRBN-G3GKV-SXFH4"
        }), this.getLocation(), this.getDistrictData(function(t) {
            e.init({
                page: n,
                data: t
            });
        });
    },
    getDistrictData: function(t) {
        var e = getApp().core.getStorageSync(getApp().const.DISTRICT);
        if (!e) return getApp().core.showLoading({
            title: "正在加载",
            mask: !0
        }), void getApp().request({
            url: getApp().api.default.district,
            success: function(o) {
                getApp().core.hideLoading(), 0 == o.code && (e = o.data, getApp().core.setStorageSync(getApp().const.DISTRICT, e), 
                t(e));
            }
        });
        console.log("distict", e), e = this.addFullAddress(e), console.log("distict", e), 
        t(e);
    },
    addFullAddress: function(t) {
        for (var e = 0; e < t.length; e++) for (var o = 0; o < t[e].list.length; o++) t[e].list[o].list && t[e].list[o].list.unshift({
            id: 0,
            name: "不选择"
        });
        return t;
    },
    onAreaPickerConfirm: function(t) {
        this.setData({
            edit_district: {
                province: {
                    id: t[0].id,
                    name: t[0].name
                },
                city: {
                    id: t[1].id,
                    name: t[1].name
                },
                district: {
                    id: t[2].id,
                    name: t[2].name
                }
            }
        });
    },
    getLocation: function() {
        var e = this;
        wx.getLocation({
            type: "wgs84",
            success: function(o) {
                console.log(o), t.reverseGeocoder({
                    coord_type: 1,
                    location: {
                        latitude: o.latitude,
                        longitude: o.longitude
                    },
                    success: function(t) {
                        console.log(t), e.setData({
                            ad_name: t.result.address,
                            ad_code: t.result.ad_info.adcode
                        });
                    },
                    fail: function(t) {
                        console.log(t);
                    },
                    complete: function(t) {
                        console.log(t);
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});