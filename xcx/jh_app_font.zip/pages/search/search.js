Page({
    data: {
        load_more_count: 0,
        last_load_more_time: 0,
        is_loading: !1,
        loading_class: "",
        cat_id: !1,
        keyword: !1,
        page: 1,
        limit: 20,
        pageCount: 0,
        goods_list: [],
        show_history: !0,
        show_result: !1,
        history_list: [],
        is_search: !0,
        is_show: !1,
        cats: [],
        default_cat: []
    },
    onLoad: function(t) {
        getApp().page.onLoad(this, t), this.cats();
    },
    onReady: function(t) {
        getApp().page.onReady(this);
    },
    onShow: function(t) {
        getApp().page.onShow(this), this.setData({
            history_list: this.getHistoryList(!0)
        });
    },
    onReachBottom: function() {
        getApp().page.onReachBottom(this);
        var t = this, a = t.data.page + 1;
        a <= t.data.pageCount && (t.setData({
            page: a
        }), t.getGoodsList());
    },
    cats: function() {
        var t = this;
        getApp().request({
            url: getApp().api.default.cats,
            success: function(a) {
                0 == a.code && t.setData({
                    cats: a.data.list,
                    default_cat: a.data.default_cat
                });
            }
        });
    },
    change_cat: function(t) {
        var a = this.data.cats, e = t.currentTarget.dataset.id;
        for (var s in a) if (e === a[s].id) var i = {
            id: a[s].id,
            name: a[s].name,
            key: a[s].key,
            url: a[s].url
        };
        this.setData({
            default_cat: i
        });
    },
    pullDown: function() {
        var t = this, a = t.data.cats, e = t.data.default_cat;
        for (var s in a) a[s].id === e.id ? a[s].is_active = !0 : a[s].is_active = !1;
        t.setData({
            is_show: !t.data.is_show,
            cats: a
        });
    },
    inputFocus: function() {
        this.setData({
            show_history: !0,
            show_result: !1
        });
    },
    inputBlur: function() {
        var t = this;
        0 < t.data.goods_list.length && setTimeout(function() {
            t.setData({
                show_history: !1,
                show_result: !0
            });
        }, 300);
    },
    inputConfirm: function(t) {
        var a = this, e = t.detail.value;
        0 != e.length && (a.setData({
            page: 1,
            keyword: e,
            goods_list: []
        }), a.setHistory(e), a.getGoodsList());
    },
    searchCancel: function() {
        getApp().core.navigateBack({
            delta: 1
        });
    },
    historyClick: function(t) {
        var a = t.currentTarget.dataset.value;
        0 != a.length && (this.setData({
            page: 1,
            keyword: a,
            goods_list: []
        }), this.getGoodsList());
    },
    getGoodsList: function() {
        var t = this;
        t.setData({
            show_history: !1,
            show_result: !0,
            is_search: !0
        });
        var a = {};
        t.data.cat_id && (a.cat_id = t.data.cat_id, t.setActiveCat(a.cat_id)), t.data.keyword && (a.keyword = t.data.keyword), 
        a.defaultCat = JSON.stringify(t.data.default_cat), a.page = t.data.page, t.showLoadingBar(), 
        t.is_loading = !0, getApp().request({
            url: getApp().api.default.search,
            data: a,
            success: function(a) {
                if (0 == a.code) {
                    var e = t.data.goods_list.concat(a.data.list);
                    t.setData({
                        goods_list: e,
                        pageCount: a.data.page_count
                    }), 0 == a.data.list.length ? t.setData({
                        is_search: !1
                    }) : t.setData({
                        is_search: !0
                    });
                }
                a.code;
            },
            complete: function() {
                t.hideLoadingBar(), t.is_loading = !1;
            }
        });
    },
    getHistoryList: function(t) {
        t = t || !1;
        var a = getApp().core.getStorageSync(getApp().const.SEARCH_HISTORY_LIST);
        if (!a) return [];
        if (!t) return a;
        for (var e = [], s = a.length - 1; 0 <= s; s--) e.push(a[s]);
        return e;
    },
    setHistory: function(t) {
        var a = this.getHistoryList();
        for (var e in a.push({
            keyword: t
        }), a) {
            if (a.length <= 20) break;
            a.splice(e, 1);
        }
        getApp().core.setStorageSync(getApp().const.SEARCH_HISTORY_LIST, a);
    },
    getMoreGoodsList: function() {
        var t = this, a = {};
        t.data.cat_id && (a.cat_id = t.data.cat_id, t.setActiveCat(a.cat_id)), t.data.keyword && (a.keyword = t.data.keyword), 
        a.page = t.data.page || 1, t.showLoadingMoreBar(), t.setData({
            is_loading: !0
        }), t.setData({
            load_more_count: t.data.load_more_count + 1
        }), a.page = t.data.page + 1, a.defaultCat = t.data.default_cat, t.setData({
            page: a.page
        }), a.defaultCat = JSON.stringify(t.data.default_cat), getApp().request({
            url: getApp().api.default.search,
            data: a,
            success: function(e) {
                if (0 == e.code) {
                    var s = t.data.goods_list;
                    if (0 < e.data.list.length) {
                        for (var i in e.data.list) s.push(e.data.list[i]);
                        t.setData({
                            goods_list: s
                        });
                    } else t.setData({
                        page: a.page - 1
                    });
                }
                e.code;
            },
            complete: function() {
                t.setData({
                    is_loading: !1
                }), t.hideLoadingMoreBar();
            }
        });
    },
    showLoadingBar: function() {
        this.setData({
            loading_class: "active"
        });
    },
    hideLoadingBar: function() {
        this.setData({
            loading_class: ""
        });
    },
    showLoadingMoreBar: function() {
        this.setData({
            loading_more_active: "active"
        });
    },
    hideLoadingMoreBar: function() {
        this.setData({
            loading_more_active: ""
        });
    },
    deleteSearchHistory: function() {
        this.setData({
            history_list: null
        }), getApp().core.removeStorageSync(getApp().const.SEARCH_HISTORY_LIST);
    }
});