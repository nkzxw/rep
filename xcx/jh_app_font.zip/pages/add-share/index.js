getApp().api;

Page({
    data: {
        form: {
            name: "",
            mobile: ""
        },
        img: "/images/img-share-un.png",
        agree: 0,
        show_modal: !1,
        region: [],
        customItem: "全部",
        index: 0,
        mchSel: "请先选择地区",
        merchants: [],
        merchants_val: []
    },
    bindRegionChange: function(e) {
        console.log("picker发送选择改变，携带值为", e.detail.value);
        var a = this, t = e.detail.value;
        this.setData({
            region: t
        });
        var o = "";
        t[2] != this.data.customItem ? o = t[2] : t[1] != this.data.customItem ? o = t[1] : t[0] != this.data.customItem && (o = t[0]), 
        wx.showNavigationBarLoading(), getApp().request({
            url: getApp().api.default.mch_search,
            data: {
                key: o
            },
            success: function(e) {
                console.log(e), wx.hideNavigationBarLoading();
                var t = [], o = [];
                e.data.length || a.setData({
                    mchSel: "本地区暂无入驻商家"
                });
                for (var i = 0; i < e.data.length; i++) t.push(e.data[i].name), o.push(e.data[i].id);
                a.setData({
                    merchants: t,
                    merchants_val: o,
                    index: 0,
                    mchSel: t[0]
                });
            }
        });
    },
    bindPickerChange: function(e) {
        console.log(e), console.log("picker发送选择改变，携带值为", e.detail.value), this.setData({
            index: e.detail.value,
            mchSel: this.data.merchants[e.detail.value]
        });
    },
    onLoad: function(e) {
        getApp().page.onLoad(this, e), this.setData({
            auto_share_recharge: wx.getStorageSync("STORE_CONFIG").auto_share_recharge
        });
    },
    onReady: function() {
        getApp().page.onReady(this);
    },
    onShow: function() {
        getApp().page.onShow(this);
        var e = this, a = getApp().getUser(), t = getApp().core.getStorageSync(getApp().const.SHARE_SETTING);
        console.log(a), getApp().getConfig(function(a) {
            var t = a.store, o = "分销商";
            t && t.share_custom_data && (o = t.share_custom_data.words.share_name.name), e.setData({
                share_name: o
            }), wx.setNavigationBarTitle({
                title: "申请成为" + o
            });
        }), getApp().core.showLoading({
            title: "加载中"
        }), e.setData({
            share_setting: t
        }), getApp().request({
            url: getApp().api.share.check,
            method: "POST",
            success: function(t) {
                0 == t.code && (a.is_distributor = t.data, getApp().setUser(a), 1 == t.data && getApp().core.redirectTo({
                    url: "/pages/share/index"
                })), e.setData({
                    __user_info: a
                });
            },
            complete: function() {
                getApp().core.hideLoading();
            }
        });
    },
    onHide: function() {
        getApp().page.onHide(this);
    },
    onUnload: function() {
        getApp().page.onUnload(this);
    },
    formSubmit: function(e) {
        var a = this, t = getApp().getUser();
        if (a.data.form = e.detail.value, null != a.data.form.name && "" != a.data.form.name) if (null != a.data.form.mobile && "" != a.data.form.mobile) if (a.data.__user_info.mch_id ? a.data.form.mch_id = a.data.__user_info.mch_id : a.data.merchants_val[a.data.index] ? a.data.form.mch_id = a.data.merchants_val[a.data.index] : getApp().core.showToast({
            title: "必须选择一个商家",
            image: "/images/icon-warning.png"
        }), /^\+?\d[\d -]{8,12}\d/.test(a.data.form.mobile)) {
            var o = e.detail.value;
            o.form_id = e.detail.formId, 0 != a.data.agree ? (getApp().core.showLoading({
                title: "正在提交",
                mask: !0
            }), getApp().request({
                url: getApp().api.share.join,
                method: "POST",
                data: o,
                success: function(e) {
                    0 == e.code ? (t.is_distributor = 2, getApp().setUser(t), getApp().core.redirectTo({
                        url: "/pages/add-share/index"
                    })) : console.log("msg", e.msg) && getApp().core.showToast({
                        title: e.msg,
                        image: "/images/icon-warning.png"
                    });
                }
            })) : getApp().core.showToast({
                title: "请先阅读并确认分销申请协议！！",
                image: "/images/icon-warning.png"
            });
        } else getApp().core.showModal({
            title: "提示",
            content: "手机号格式不正确",
            showCancel: !1
        }); else getApp().core.showToast({
            title: "请填写联系方式！",
            image: "/images/icon-warning.png"
        }); else getApp().core.showToast({
            title: "请填写姓名！",
            image: "/images/icon-warning.png"
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    agreement: function() {
        getApp().core.getStorageSync(getApp().const.SHARE_SETTING), this.setData({
            show_modal: !0
        });
    },
    agree: function() {
        var e = this, a = e.data.agree;
        0 == a ? (a = 1, e.setData({
            img: "/images/img-share-agree.png",
            agree: a
        })) : 1 == a && (a = 0, e.setData({
            img: "/images/img-share-un.png",
            agree: a
        }));
    },
    close: function() {
        this.setData({
            show_modal: !1,
            img: "/images/img-share-agree.png",
            agree: 1
        });
    }
});