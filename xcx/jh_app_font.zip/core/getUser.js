module.exports = function() {
    return this.core.getStorageSync(this.const.USER_INFO) || "";
};