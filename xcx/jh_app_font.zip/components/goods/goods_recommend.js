module.exports = {
    currentPage: null,
    init: function(o) {
        var t = this;
        void 0 === (t.currentPage = o).goods_recommend && (o.goods_recommend = function(o) {
            t.goods_recommend(o);
        });
    },
    goods_recommend: function(o) {
        var t = this.currentPage;
        t.setData({
            is_loading: !0
        });
        var a = t.data.page || 2;
        getApp().request({
            url: getApp().api.default.goods_recommend,
            data: {
                goods_id: o.goods_id,
                page: a
            },
            success: function(e) {
                if (0 == e.code) {
                    if (o.reload) var d = e.data.list;
                    o.loadmore && (d = t.data.goods_list.concat(e.data.list)), t.data.drop = !0, t.setData({
                        goods_list: d
                    }), t.setData({
                        page: a + 1
                    });
                }
            },
            complete: function() {
                t.setData({
                    is_loading: !1
                });
            }
        });
    }
};